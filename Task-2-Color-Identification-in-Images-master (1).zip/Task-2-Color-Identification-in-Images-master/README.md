# Task-2-Color-Identification-in-Images
An image color detector which identifies all the colors in an image or video.
